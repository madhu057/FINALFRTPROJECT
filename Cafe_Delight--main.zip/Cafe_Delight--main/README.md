### CAFE DELIGHT
#### This is the readme file for the FRT Project developed by Balraj Upadhyay, Virat Desale and Prathmesh Joshi

###### Industry:- Lifestyle
###### Project Title:- Cafe Management and Online Booking Application.
###### Problem Statement/Opportunity:- Cafe Delight is One of the best Cafes in Pune Serving People with Rich Quality Delicious and Variety of items. Now,the Owners want to a step forward with Launching their web Application and Providing the Customers with Online Booking Features to tackle covid-19 Restrictions. Using Azure Cloud Platform, create a Web Application for the Cafe with Online Booking Systems, Available Menu, details of the Chefs and a map to find the Way to Cafe. Make sure the Customer receives a Booking Confirmation mail along with the details filled by them.
###### Project Description:- The Motive behind this Project is to help Small Businesses to Digital and allow them to expand their reach to Market. We aim to build a Prototype Website using HTML,CSS,JAVASCRIPT and BOOTSTRAP that introduces the Customers with an Online Version of the Shop. This Website allows Customers to make a Reservation with cafe, View what's on the Menu and Directions for the Shop using maps. We've also included a Feature that confirms your Booking through your Mail provided while Booking.
###### Primary Azure Technology:- Static Web Apps
###### Other Azure Technologies:- HTML,CSS,JAVASCRIPT,BOOTSTRAP,VS-Code
